from wheel1 import hello as hello1
from wheel2 import hello as hello2
from wheel3 import hello as hello3
from wheel4 import hello as hello4
from wheel5 import hello as hello5
from wheel6 import hello as hello6


def hello():
    hello1()
    hello2()
    hello3()
    hello4()
    hello5()
    hello6()
    print("Hello from root!")
